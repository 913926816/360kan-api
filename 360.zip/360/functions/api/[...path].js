import { extractDataFrom360Kan, extractSearchResults } from '../../360kan-regex-scraper.js';

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const CATEGORY_URLS = {
  tv: 'https://www.360kan.com/dianshi/index.html',
  variety: 'https://www.360kan.com/zongyi/index.html',
  movie: 'https://www.360kan.com/dianying/index.html',
  anime: 'https://www.360kan.com/dongman/index.html'
};

async function fetchHtml(url) {
  const response = await fetch(url, {
    headers: {
      'User-Agent': USER_AGENT,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
    }
  });
  
  if (!response.ok) {
    throw new Error(`Failed to fetch ${url}: ${response.status}`);
  }
  
  return await response.text();
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  });
}

function errorResponse(message, status = 500) {
  return jsonResponse({ error: message }, status);
}

export async function onRequest(context) {
  const { request } = context;
  const url = new URL(request.url);
  const path = url.pathname;
  
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      }
    });
  }
  
  if (request.method !== 'GET') {
    return errorResponse('Method not allowed', 405);
  }
  
  try {
    if (path === '/api/home' || path === '/api/home/') {
      const html = await fetchHtml('https://www.360kan.com/');
      const data = extractDataFrom360Kan(html, 'home');
      return jsonResponse(data);
    }
    
    if (path === '/api/search' || path === '/api/search/') {
      const keyword = url.searchParams.get('kw');
      if (!keyword) {
        return errorResponse('Missing required parameter: kw', 400);
      }
      
      const searchUrl = `https://so.360kan.com/?kw=${encodeURIComponent(keyword)}`;
      const html = await fetchHtml(searchUrl);
      const results = extractSearchResults(html);
      return jsonResponse({
        page_type: 'search',
        search_url: searchUrl,
        keyword: keyword,
        results: results
      });
    }
    
    if (path === '/api/category' || path === '/api/category/') {
      const type = url.searchParams.get('type');
      if (!type || !CATEGORY_URLS[type]) {
        return errorResponse('Invalid or missing parameter: type. Must be one of: tv, variety, movie, anime', 400);
      }
      
      const html = await fetchHtml(CATEGORY_URLS[type]);
      const data = extractDataFrom360Kan(html, 'category', type);
      return jsonResponse(data);
    }
    
    return errorResponse('Endpoint not found', 404);
    
  } catch (error) {
    console.error('API Error:', error);
    return errorResponse(error.message || 'Internal server error', 500);
  }
}
