// 360影视数据抓取脚本（基于正则表达式）
// 用于动态提取360影视首页数据并生成JSON格式

/**
 * 提取导航菜单数据
 * @param {string} html - 页面HTML内容
 * @returns {Array} 导航菜单项数组
 */
function extractNavigation(html) {
  const navRegex = /<a\s+[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
  const navItems = [];
  let match;
  
  while ((match = navRegex.exec(html)) !== null) {
    const url = match[1];
    const name = match[2].trim();
    // 过滤掉不需要的链接
    if (name && url && 
        !name.includes('登录') && 
        !name.includes('看过') && 
        !name.includes('收藏') &&
        !name.includes('全网搜') &&
        name.length > 0 &&
        url.length > 0) {
      navItems.push({ name, url });
    }
  }
  
  // 去重并过滤无效项
  return navItems.filter((item, index, self) => 
    index === self.findIndex((t) => t.name === item.name)
  );
}

/**
 * 提取推荐节目数据
 * @param {string} html - 页面HTML内容
 * @returns {Array} 推荐节目数组
 */
function extractRecommendedShows(html) {
  const recommendedShowsRegex = /<a\s+[^>]*href="([^"]+)"[^>]*>.*?<span[^>]*>([\s\S]*?)<\/span>.*?<span[^>]+class=["']tab-desc["']>.*?[|]([\s\S]*?)<\/span>/gs;
  const shows = [];
  let match;
  
  while ((match = recommendedShowsRegex.exec(html)) !== null) {
    const url = match[1];
    const name = match[2].trim();
    const description = match[3].trim();
    if (name && url) {
      shows.push({ name, url, description });
    }
  }
  
  return shows;
}

/**
 * 提取猜你喜欢数据
 * @param {string} html - 页面HTML内容
 * @returns {Array} 猜你喜欢项数组
 */
function extractLikeItems(html) {
  const likeItemsRegex = /<a\s+[^>]*href="([^"]+)"[^>]*class=["']banner-feature-item["'].*?<p[^>]+class=["']title["']>([\s\S]*?)<\/p>.*?<p[^>]+class=["']desc["']>([\s\S]*?)<\/p>/gs;
  const items = [];
  let match;
  
  while ((match = likeItemsRegex.exec(html)) !== null) {
    const url = match[1];
    const title = match[2].trim();
    const desc = match[3].trim();
    if (title && url) {
      items.push({ title, url, desc });
    }
  }
  
  return items;
}

/**
 * 提取搜索结果数据
 * @param {string} html - 搜索页面HTML内容
 * @returns {Array} 搜索结果数组
 */
function extractSearchResults(html) {
  const results = [];
  
  // 搜索结果项正则表达式 - 更灵活的匹配
  const searchResultRegex = /<div[^>]*class="p-longvideo[^>]*>([\s\S]*?)(?=<div[^>]*class="playsiteWrap|$)/gs;
  
  let match;
  while ((match = searchResultRegex.exec(html)) !== null) {
    const itemHtml = match[1];
    
    // 提取标题和链接
    const titleRegex = /<h3[^>]*class="title"[^>]*>[\s\S]*?<a[^>]*href="([^"]+)"[^>]*>[\s\S]*?<b>([^<]+)<\/b>/;
    const titleMatch = titleRegex.exec(itemHtml);
    
    if (!titleMatch) continue;
    
    const url = titleMatch[1];
    const title = titleMatch[2].trim();
    
    // 提取类型
    const typeRegex = /<span[^>]*class="playtype"[^>]*>([\s\S]*?)<\/span>/;
    const typeMatch = typeRegex.exec(itemHtml);
    const type = typeMatch ? typeMatch[1].trim() : '';
    
    // 提取地区
    const areaRegex = /<li[^>]*class="area"[^>]*>[\s\S]*?<span[^>]*>([\s\S]*?)<\/span>/;
    const areaMatch = areaRegex.exec(itemHtml);
    const area = areaMatch ? areaMatch[1].trim() : '';
    
    // 提取主演
    const actorRegex = /<li[^>]*class="actor[^>]*>([\s\S]*?)<\/li>/;
    const actorMatch = actorRegex.exec(itemHtml);
    
    let actors = [];
    if (actorMatch) {
      const actorText = actorMatch[1];
      const actorLinkRegex = /<a[^>]*>([^<]+)<\/a>/g;
      let actorLinkMatch;
      while ((actorLinkMatch = actorLinkRegex.exec(actorText)) !== null) {
        actors.push(actorLinkMatch[1].trim());
      }
    }
    
    // 提取简介
    const descRegex = /<p[^>]*><i[^>]*>简&nbsp;&nbsp;介&nbsp;：<\/i>([\s\S]*?)<\/p>/;
    const descMatch = descRegex.exec(itemHtml);
    const description = descMatch ? descMatch[1].trim() : '';
    
    results.push({
      title,
      url,
      type,
      area,
      actors,
      description
    });
  }
  
  return results;
}

/**
 * 提取分类页面热门推荐数据
 * @param {string} html - 分类页面HTML内容
 * @returns {Array} 热门推荐数组
 */
function extractCategoryHotItems(html) {
  const items = [];
  
  // 热门推荐正则表达式
  const hotItemRegex = /<a[^>]*href="([^"]+)"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"[^>]*>[\s\S]*?<span[^>]*>([^<]+)<\/span>[\s\S]*?<p[^>]*>([^<]+)<\/p>[\s\S]*?<p[^>]*>([^<]+)<\/p>/gs;
  
  let match;
  while ((match = hotItemRegex.exec(html)) !== null) {
    const url = match[1];
    const img = match[2];
    const episodes = match[3].trim();
    const title = match[4].trim();
    const desc = match[5].trim();
    
    if (title && url) {
      items.push({
        title,
        url,
        img,
        episodes,
        desc
      });
    }
  }
  
  return items;
}

/**
 * 提取分类页面标签数据
 * @param {string} html - 分类页面HTML内容
 * @returns {Array} 标签数组
 */
function extractCategoryTags(html) {
  const tags = [];
  
  // 热门标签正则表达式
  const tagRegex = /<a[^>]*href="([^"]+)"[^>]*>([^<]+)<\/a>/g;
  
  let match;
  while ((match = tagRegex.exec(html)) !== null) {
    const url = match[1];
    const name = match[2].trim();
    
    if (name && url && name.length > 1) {
      tags.push({ name, url });
    }
  }
  
  // 去重
  return tags.filter((item, index, self) => 
    index === self.findIndex((t) => t.name === item.name)
  );
}

/**
 * 从360影视页面提取数据
 * @param {string} html - 页面HTML内容
 * @param {string} pageType - 页面类型: 'home', 'search', 'category'
 * @param {string} categoryType - 分类类型: 'tv', 'variety', 'movie', 'anime'
 * @returns {Object} 提取的数据对象
 */
function extractDataFrom360Kan(html, pageType = 'home', categoryType = '') {
  if (pageType === 'search') {
    return {
      page_type: 'search',
      search_url: 'https://so.360kan.com/?kw=',
      results: extractSearchResults(html)
    };
  } else if (pageType === 'category') {
    const categoryUrls = {
      tv: 'https://www.360kan.com/dianshi/index.html',
      variety: 'https://www.360kan.com/zongyi/index.html',
      movie: 'https://www.360kan.com/dianying/index.html',
      anime: 'https://www.360kan.com/dongman/index.html'
    };
    return {
      page_type: 'category',
      category_type: categoryType,
      category_url: categoryUrls[categoryType] || '',
      hot_items: extractCategoryHotItems(html),
      tags: extractCategoryTags(html)
    };
  } else {
    return {
      page_type: 'home',
      navigation: extractNavigation(html),
      recommended_shows: extractRecommendedShows(html),
      like_items: extractLikeItems(html)
    };
  }
}

/**
 * 示例：如何使用这个脚本
 * 1. 获取360影视首页的HTML内容
 * 2. 调用extractDataFrom360Kan函数提取数据
 * 3. 将提取的数据转换为JSON格式
 */

// 示例1：使用axios获取HTML（适用于简单页面）
/*
const axios = require('axios');
async function get360KanData() {
  try {
    const response = await axios.get('https://www.360kan.com/', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const html = response.data;
    const data = extractDataFrom360Kan(html);
    console.log(JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('获取数据失败:', error.message);
  }
}
*/

// 示例2：使用puppeteer获取HTML（适用于单页应用）
/*
const puppeteer = require('puppeteer');
async function get360KanDataWithPuppeteer() {
  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    await page.goto('https://www.360kan.com/', {
      waitUntil: 'networkidle2',
      timeout: 30000
    });
    await page.waitForTimeout(5000);
    const html = await page.content();
    const data = extractDataFrom360Kan(html);
    console.log(JSON.stringify(data, null, 2));
    await browser.close();
  } catch (error) {
    console.error('获取数据失败:', error.message);
  }
}
*/

// 导出函数 - 同时支持 ES 模块和 CommonJS
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    extractNavigation,
    extractRecommendedShows,
    extractLikeItems,
    extractSearchResults,
    extractCategoryHotItems,
    extractCategoryTags,
    extractDataFrom360Kan
  };
}

if (typeof exports !== 'undefined') {
  exports.extractNavigation = extractNavigation;
  exports.extractRecommendedShows = extractRecommendedShows;
  exports.extractLikeItems = extractLikeItems;
  exports.extractSearchResults = extractSearchResults;
  exports.extractCategoryHotItems = extractCategoryHotItems;
  exports.extractCategoryTags = extractCategoryTags;
  exports.extractDataFrom360Kan = extractDataFrom360Kan;
}

export {
  extractNavigation,
  extractRecommendedShows,
  extractLikeItems,
  extractSearchResults,
  extractCategoryHotItems,
  extractCategoryTags,
  extractDataFrom360Kan
};
